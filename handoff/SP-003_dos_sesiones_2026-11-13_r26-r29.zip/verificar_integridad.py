import hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent
n=0
for line in (r/'MANIFIESTO_SHA256.txt').read_text(encoding='utf8').splitlines():
 digest,rel=line.split('  ',1)
 p=(r/rel).resolve()
 assert p.is_relative_to(r) and p.is_file(),rel
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,rel
 n+=1
print(str(n)+' hashes correctos.')
